from django.shortcuts import render,redirect
from CrudApp.models import college
from CrudApp.forms import CollegeForm
# Create your views here.
def view_fun(request):
	obj = college.objects.all()
	return render(request,'CrudApp/index.html',{'college':obj})

def create_fun(request):
	form = CollegeForm()
	if request.method=='POST':
		form = CollegeForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect('/crud')
	return render(request,'CrudApp/create.html',{'form':form})

def del_fun(request,id):
	d=college.objects.get(id=id)
	d.delete()
	return redirect('/crud')

def update_fun(request,id):
	d=college.objects.get(id=id)
	if request.method=='POST':
		form = CollegeForm(request.POST,instance=d)
		if form.is_valid():
			form.save()
			return redirect('/crud')
	return render(request,'CrudApp/update.html',{'form':d})


 