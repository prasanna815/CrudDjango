from django.contrib import admin
from CrudApp.models import college
# Register your models here.
class collegeAdmin(admin.ModelAdmin):
	l=['roll_no','name','department','section']
admin.site.register(college,collegeAdmin)

