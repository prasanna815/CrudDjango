from django import forms
from CrudApp.models import college
class CollegeForm(forms.ModelForm):
	class Meta:
		model = college
		fields = '__all__'