from django.db import models

# Create your models here.
class college(models.Model):
	roll_no=models.IntegerField()
	name=models.CharField(max_length=30)
	department=models.CharField(max_length=20)
	section=models.CharField(max_length=1)
	